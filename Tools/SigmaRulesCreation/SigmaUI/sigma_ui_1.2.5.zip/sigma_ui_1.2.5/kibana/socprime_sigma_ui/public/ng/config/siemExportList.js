let data = {
    "es-qs": {
        "name": "Elasticsearch",
    },
    "elasticsearch-rule": {
        "name": "Elastic Rule",
    },
    "xpack-watcher": {
        "name": "X-Pack Watcher",
    },
    "kibana": {
        "name": "Kibana",
    },
    "arcsight": {
        "name": "ArcSight Keyword",
    },
    "arcsight-esm": {
        "name": "ArcSight Rule",
    },
    "carbonblack": {
        "name": "Carbonblack",
    },
    "ala": {
        "name": "Azure Sentinel Query",
    },
    "ala-rule": {
        "name": "Azure Sentinel Rule",
    },
    "qualys": {
        "name": "Qualys",
    },
    "qradar": {
        "name": "QRadar",
    },
    "splunk": {
        "name": "Splunk",
    },
    "logpoint": {
        "name": "Logpoint",
    },
    "graylog": {
        "name": "Graylog",
    },
    "grep": {
        "name": "Regex Grep",
    },
    "wdatp": {
        "name": "Windows Defender ATP",
    },
    "powershell": {
        "name": "Windows PowerShell",
    },
    "sumologic": {
        "name": "Sumo Logic",
    },
    "netwitness": {
        "name": "RSA NetWitness",
    }
};

module.exports = data;
